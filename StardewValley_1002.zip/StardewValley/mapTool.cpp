#include "stdafx.h"
#include "mapTool.h"

LPTSTR	g_lpszClass2 = (LPTSTR)TEXT("MapTool");

RECT rc;

mapTool::mapTool()
{
	
}

mapTool::~mapTool()
{
}

HRESULT mapTool::init()
{
	//m_hWndPopUp = CreateWindow(g_lpszClass2, g_lpszClass2, WS_OVERLAPPEDWINDOW, WINSTARTX,
	//	WINSTARTY,
	//	WINSIZEX,
	//	WINSIZEY, g_hWnd, (HMENU)NULL, g_hInstance, NULL);

	m_pTileSet = IMAGEMANAGER->findImage("earth");
	m_pObject = IMAGEMANAGER->findImage("earthObj");
	m_pbg = IMAGEMANAGER->findImage("whitebackground");

	g_hWndChildSample = CreateWindow(TEXT("MapSample"), NULL, WS_CHILD | WS_VISIBLE,
		16 * TILE_X, 300, WINSIZEX - 16 * TILE_X, 500, g_hWnd, (HMENU)0, g_hInstance, NULL);

	m_nImageX = WINSIZEX - m_pTileSet->getWidth();
	m_isObject = false;

	//	�⺻ Ÿ�� ���� ����
	for (int y = 0; y < TILE_Y; y++)
	{
		for (int x = 0; x < TILE_X; x++)
		{
			m_pTiles[y * TILE_X + x].rc = RectMake(x * TILE_SIZE_1, y * TILE_SIZE_1, TILE_SIZE_1, TILE_SIZE_1);
			m_pTiles[y * TILE_X + x].terrainFrameX = 1;
			m_pTiles[y * TILE_X + x].terrainFrameY = 0;
			m_pTiles[y * TILE_X + x].terrain = NOMALTILE;
			m_pTiles[y * TILE_X + x].object = OBJ_NULL;
		}
	}
	
	for (int i = 0; i < SAMPLE_TILE_X * SAMPLE_TILE_Y; i++)
	{
		m_pSampleTiles[i].rc = RectMake(m_nImageX + (i % SAMPLE_TILE_X) * TILE_SIZE_1, (i / SAMPLE_TILE_X) * TILE_SIZE_1, TILE_SIZE_1, TILE_SIZE_1);
		m_pSampleTiles[i].frameX = i % SAMPLE_TILE_X;
		m_pSampleTiles[i].frameY = i / SAMPLE_TILE_X;
		m_pSampleTiles[i].index = i;
		m_pSampleTiles[i].object = MYHOME;
	}

	m_vecSelectedTile.reserve(SAMPLE_TILE_X * SAMPLE_TILE_Y);
	return S_OK;
}

void mapTool::release()
{
}

void mapTool::update()
{
	sampleTileSave();

	if (m_isObject)
		TileObjSet();

	else
		TileSet();

	m_vecSelectedTile.clear();
}

void mapTool::render(HDC hdc)
{
	// ��׶���
	if (m_pbg)
		m_pbg->render(hdc, 0, 0);
	   	
	if (m_isObject)
	{
		m_pObject->render(hdc, WINSIZEX - m_pObject->getWidth(), 0);

		// Ȯ��
		//m_pObject->frameRender(hdc, 800, 500, m_rcSelectedTile.left, m_rcSelectedTile.top);
	}

	else
	{
		// Ÿ��
		if (m_pTileSet)
			m_pTileSet->render(hdc, m_nImageX, 0);
	}

	// �� Ÿ��
	for (int y = 0; y < TILE_Y; y++)
	{
		for (int x = 0; x < TILE_X; x++)
		{
			m_pTileSet->frameRender(hdc, m_pTiles[y*TILE_X + x].rc.left,
				m_pTiles[y*TILE_X + x].rc.top, m_pTiles[y*TILE_X + x].terrainFrameX,
				m_pTiles[y*TILE_X + x].terrainFrameY);
		}
	}

	for (int y = 0; y < TILE_Y; ++y)
	{
		for (int x = 0; x < TILE_X ; ++x)
		{			
			// ������Ʈ
			if (m_pTiles[y*TILE_X + x].object != OBJ_NULL)
			{
				m_pObject->frameRender(hdc,
					m_pTiles[y*TILE_X + x].rc.left,
					m_pTiles[y*TILE_X + x].rc.top,
					m_pTiles[y*TILE_X + x].objectFrameX,
					m_pTiles[y*TILE_X + x].objectFrameY);
			}
		}
	}


	if (m_isDrag)
	{
		Rectangle(hdc, rc.left, rc.top, rc.right, rc.bottom);
	}

}

LRESULT mapTool::MainProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;

	switch (iMessage)
	{
	case WM_CREATE:
		rc = RectMakeCenter(0, 0, 0, 0);
		break;

	case WM_LBUTTONDOWN:
		g_ptMouse.x = LOWORD(lParam);
		g_ptMouse.y = HIWORD(lParam);
		rc.left = LOWORD(lParam);
		rc.top = HIWORD(lParam);
		m_isClick = true;
		return 0;

	case WM_MOUSEMOVE:
		if (m_isClick)
		{
			m_isDrag = true;
			g_ptMouse.x = LOWORD(lParam);
			g_ptMouse.y = HIWORD(lParam);	
			rc.right = LOWORD(lParam);
			rc.bottom = HIWORD(lParam);
		}

		else
		{
			g_ptMouse.x = LOWORD(lParam);
			g_ptMouse.y = HIWORD(lParam);
		}
		return 0;

	case WM_LBUTTONUP:
		m_isClick = false;
		m_isDrag = false;
		m_rcSave = rc;
		m_isAddvec = true;
		rc = RectMakeCenter(0, 0, 0,0);
		return 0;

	case WM_INITDIALOG:
		break;

	case WM_PRINT:
		break;
		//case WM_COMMAND:
		//{
		//	switch (LOWORD(wParam))
		//	{
		//		//save
		//	case 0:
		//		OPENFILENAME ofn;

		//		ZeroMemory(&ofn, sizeof(OPENFILENAME));
		//		ofn.lStructSize = sizeof(OPENFILENAME);
		//		ofn.hwndOwner = hWnd;
		//		ofn.lpstrFilter = _T("Map Files(*.map)\0*.map\0All Files (*.*)\0*.*\0");
		//		ofn.lpstrFile = szFileName;
		//		ofn.nMaxFile = nFileNameMaxLen;
		//		ofn.lpstrDefExt = "map";
		//		//ofn.nFilterIndex = 1;
		//		//ofn.lpstrFileTitle = szFileName;
		//		//ofn.nMaxFileTitle = 0;
		//		//ofn.lpstrInitialDir = NULL;
		//		ofn.Flags = OFN_OVERWRITEPROMPT;
		//		GetSaveFileName(&ofn);

		//		//if (0 != GetOpenFileName(&OFN))
		//		//{
		//		//}
		//		
		//		m_pTileMap->saveMap(szFileName);
		//		//MessageBox(g_hWnd, TEXT("dd"), TEXT("ddkkk"), MB_OK);
		//		break;

		//		// load
		//	case 1:

		//		memset(&OFN, 0, sizeof(OPENFILENAME));
		//		OFN.lStructSize = sizeof(OPENFILENAME);
		//		OFN.hwndOwner = hWnd;
		//		OFN.lpstrFilter = "Map Files(*.map)\0*.map\0All Files (*.*)\0*.*\0";
		//		OFN.lpstrFile = szFileName;
		//		OFN.nMaxFile = nFileNameMaxLen;

		//		if (0 != GetOpenFileName(&OFN))
		//		{
		//			SetWindowText(hEditFileToBeOpened, OFN.lpstrFile);
		//			m_pTileMap->loadMap(OFN.lpstrFile);
		//		}
		//		return TRUE;

		//		break;

		//		// terrain
		//	case 2:
		//		m_pTileMap->setObject(false);
		//		break;

		//		// object
		//	case 3:
		//		m_pTileMap->setObject(true);
		//		break;

		//		// eraser
		//	case 4:
		//		m_pTileMap->objectEraser();
		//		break;
		//	}
		//	break;
		//}

	case WM_DESTROY:
		g_wndCount--;
		if (g_wndCount == 0)
		{
			PostQuitMessage(0);
		}
		return 0;
	}

	return DefWindowProc(hWnd, iMessage, wParam, lParam);
}

LRESULT mapTool::ChildMapSampleProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;
	RECT crt;
	//TCHAR *mes = TEXT("dd");

	switch (iMessage)
	{
	case WM_CREATE:
		return 0;

	case WM_MOUSEMOVE:
		g_ptMouse.x = LOWORD(lParam);
		g_ptMouse.y = HIWORD(lParam);
		break;
	case WM_KEYDOWN:
		switch (wParam)
		{
		case VK_LEFT:
			break;

		case VK_ESCAPE:
			break;
		}
		return 0;

	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		//TextOut(hdc, 0, 0, "dddddd", 6);
		break;

	case WM_INITDIALOG:
		break;

		//case WM_COMMAND:
		//{
		//	switch (LOWORD(wParam))
		//	{
		//		//save
		//	case 0:
		//		OPENFILENAME ofn;

		//		ZeroMemory(&ofn, sizeof(OPENFILENAME));
		//		ofn.lStructSize = sizeof(OPENFILENAME);
		//		ofn.hwndOwner = hWnd;
		//		ofn.lpstrFilter = _T("Map Files(*.map)\0*.map\0All Files (*.*)\0*.*\0");
		//		ofn.lpstrFile = szFileName;
		//		ofn.nMaxFile = nFileNameMaxLen;
		//		ofn.lpstrDefExt = "map";
		//		//ofn.nFilterIndex = 1;
		//		//ofn.lpstrFileTitle = szFileName;
		//		//ofn.nMaxFileTitle = 0;
		//		//ofn.lpstrInitialDir = NULL;
		//		ofn.Flags = OFN_OVERWRITEPROMPT;
		//		GetSaveFileName(&ofn);

		//		//if (0 != GetOpenFileName(&OFN))
		//		//{
		//		//}
		//		
		//		m_pTileMap->saveMap(szFileName);
		//		//MessageBox(g_hWnd, TEXT("dd"), TEXT("ddkkk"), MB_OK);
		//		break;

		//		// load
		//	case 1:

		//		memset(&OFN, 0, sizeof(OPENFILENAME));
		//		OFN.lStructSize = sizeof(OPENFILENAME);
		//		OFN.hwndOwner = hWnd;
		//		OFN.lpstrFilter = "Map Files(*.map)\0*.map\0All Files (*.*)\0*.*\0";
		//		OFN.lpstrFile = szFileName;
		//		OFN.nMaxFile = nFileNameMaxLen;

		//		if (0 != GetOpenFileName(&OFN))
		//		{
		//			SetWindowText(hEditFileToBeOpened, OFN.lpstrFile);
		//			m_pTileMap->loadMap(OFN.lpstrFile);
		//		}
		//		return TRUE;

		//		break;

		//		// terrain
		//	case 2:
		//		m_pTileMap->setObject(false);
		//		break;

		//		// object
		//	case 3:
		//		m_pTileMap->setObject(true);
		//		break;

		//		// eraser
		//	case 4:
		//		m_pTileMap->objectEraser();
		//		break;
		//	}
		//	break;
		//}

	case WM_SIZE:
		if (wParam != SIZE_MINIMIZED)
		{
			GetClientRect(g_hWnd, &crt);
			MoveWindow(g_hWndChildSample, 1000, 0, 500, 500, true);
		}
		return 0;

	}

	return DefWindowProc(hWnd, iMessage, wParam, lParam);
}

void mapTool::sampleTileSave()
{
	RECT rcTemp;

	for (int y = 0; y < SAMPLE_TILE_Y; ++y)
	{
		for (int x = 0; x < SAMPLE_TILE_X; x++)
		{
			if (!(m_rcSave.left == g_ptMouse.x && m_rcSave.top == g_ptMouse .y&& m_rcSave.right == 0&& m_rcSave.bottom == 0))
			{
				if (IntersectRect(&rcTemp, &m_pSampleTiles[y* SAMPLE_TILE_X + x].rc, &m_rcSave))
				{
					int iIndex = y * SAMPLE_TILE_X + x;
					m_vecSelectedTile.push_back(iIndex);
					m_isDragSave = true;
				}
			}

			else
			{
				if (PtInRect(&m_pSampleTiles[y* SAMPLE_TILE_X + x].rc, g_ptMouse))
				{
					m_isClickSave = true;
					m_sampleTileIndex = y * SAMPLE_TILE_X + x;
					//m_rcSelectedTile.left = m_pSampleTiles[(y* SAMPLE_TILE_X) + x].frameX;
					//m_rcSelectedTile.top = m_pSampleTiles[(y* SAMPLE_TILE_X) + x].frameY;
					//m_rcSelectedTile.top = m_pSampleTiles[(y* SAMPLE_TILE_X) + x].object;
					break;
				}
			}
		}
	}

	if (m_isAddvec && m_isDragSave)
	{
		m_selectNum = m_vecSelectedTile.back() - m_vecSelectedTile.front();
		m_selectX = m_selectNum % SAMPLE_TILE_X + 1; //x
		m_selectY = m_selectNum / SAMPLE_TILE_X + 1; //y		

		// ������ġ
		m_startX = m_vecSelectedTile.front() % SAMPLE_TILE_X;
		m_startY = m_vecSelectedTile.front() / SAMPLE_TILE_X;
		m_isAddvec = false;
	}

	m_rcSave = RectMakeCenter(0, 0, 0, 0);


}

void mapTool::TileSet()
{
	// ����Ÿ�� ���� �޾ƿ�
	if (KEYMANAGER->isStayKeyDown(VK_LBUTTON))
	{	
		if (m_isDragSave)
		{
			for (int y = 0; y < TILE_Y; ++y)
			{
				for (int x = 0; x < TILE_X; ++x)
				{
					if (PtInRect(&m_pTiles[y* TILE_X + x].rc, g_ptMouse))
					{
						for (int y2 = 0; y2 < m_selectY; y2++)
						{
							for (int x2 = 0; x2 < m_selectX; x2++)
							{
								m_pTiles[(y + y2)* TILE_X + (x + x2)].terrainFrameX = m_pSampleTiles[(m_startY + y2)* SAMPLE_TILE_X + (m_startX + x2)].frameX;
								m_pTiles[(y + y2)* TILE_X + (x + x2)].terrainFrameY = m_pSampleTiles[(m_startY + y2)* SAMPLE_TILE_X + (m_startX + x2)].frameY;
								m_pTiles[(y + y2)* TILE_X + (x + x2)].terrain = m_pSampleTiles[(m_startY + y2)* SAMPLE_TILE_X + (m_startX + x2)].terrain;
							}
						}
					}
				}
			}
			m_isDragSave = false;
		}

		else if(m_isClickSave)
		{
			for (int y = 0; y < TILE_Y; ++y)
			{
				for (int x = 0; x < TILE_X; ++x)
				{
					if (PtInRect(&m_pTiles[y* TILE_X + x].rc, g_ptMouse))
					{
						//m_pTiles[y* TILE_X + x].terrainFrameX = m_rcSelectedTile.left;
						//m_pTiles[y* TILE_X + x].terrainFrameY = m_rcSelectedTile.top;
						m_pTiles[y* TILE_X + x].terrainFrameX = m_pSampleTiles[m_sampleTileIndex].frameX;
						m_pTiles[y* TILE_X + x].terrainFrameY = m_pSampleTiles[m_sampleTileIndex].frameY;
						m_pTiles[y* TILE_X + x].terrain = m_pSampleTiles[m_sampleTileIndex].terrain;
						break;
					}
				}
			}
			m_isClickSave = false;
		}


	}
}

void mapTool::TileObjSet()
{
	//		if (m_isObject)

	if (KEYMANAGER->isStayKeyDown(VK_LBUTTON))
	{
		if (m_isDragSave)
		{
			for (int y = 0; y < TILE_Y; ++y)
			{
				for (int x = 0; x < TILE_X; ++x)
				{
					if (PtInRect(&m_pTiles[y* TILE_X + x].rc, g_ptMouse))
					{
						for (int y2 = 0; y2 < m_selectY; y2++)
						{
							for (int x2 = 0; x2 < m_selectX; x2++)
							{
								m_pTiles[(y + y2)* TILE_X + (x + x2)].objectFrameX = m_pSampleTiles[(m_startY + y2)* SAMPLE_TILE_X + (m_startX + x2)].frameX;
								m_pTiles[(y + y2)* TILE_X + (x + x2)].objectFrameY = m_pSampleTiles[(m_startY + y2)* SAMPLE_TILE_X + (m_startX + x2)].frameY;
								m_pTiles[(y + y2)* TILE_X + (x + x2)].object = m_pSampleTiles[(m_startY + y2)* SAMPLE_TILE_X + (m_startX + x2)].object;
							}
						}
					}
				}
			}
			m_isDragSave = false;
		}

		else if (m_isClickSave)
		{
			for (int y = 0; y < TILE_Y; ++y)
			{
				for (int x = 0; x < TILE_X; ++x)
				{
					if (PtInRect(&m_pTiles[y* TILE_X + x].rc, g_ptMouse))
					{
						//m_pTiles[y* TILE_X + x].objectFrameX = m_rcSelectedTile.left;
						//m_pTiles[y* TILE_X + x].objectFrameY = m_rcSelectedTile.top;
						m_pTiles[y* TILE_X + x].objectFrameX = m_pSampleTiles[m_sampleTileIndex].frameX;
						m_pTiles[y* TILE_X + x].objectFrameY = m_pSampleTiles[m_sampleTileIndex].frameY;
						m_pTiles[y* TILE_X + x].object = m_pSampleTiles[m_sampleTileIndex].object;						
						break;
					}
				}
			}
			m_isClickSave = false;
		}
	}

}

void mapTool::objectEraser()
{
}
