#pragma once
#include "scene.h"
#include <vector>

#define TILE_X	50
#define TILE_Y	50

#define SAMPLE_TILE_X	10
#define SAMPLE_TILE_Y	10

#define TILE_SIZE_1	16
#define TILE_SIZE_2	32


enum TERRAIN
{
	NOMALTILE,
	WATER,
	EARTH,
	CEMENT,
	ROAD,
	TR_NUM
};

enum OBJECT
{
	OBJ_NULL,
	BLOCK_1,
	BLOCK_2,
	FLAG_RED,
	FLAG_BLUE,
	BUSH_1,
	BUSH_2,
	BUSH_3,
	ROCK_BIG,
	ROCK_SMALL,
	BRANCH_1,
	HOUSE,
	MYHOME,
	SHOP,
	OB_NUM
};

struct tagTile
{
	TERRAIN terrain;
	OBJECT object;

	int terrainFrameX; // Ÿ���� ������ �ִ� ��������
	int terrainFrameY;

	int objectFrameX; // Ÿ���� ������ �ִ� ������Ʈ����
	int objectFrameY;

	int index;

	RECT rc;
};

struct tagSampleTile
{
	TERRAIN terrain;
	OBJECT object;

	int frameX;
	int frameY;
	int index;

	RECT rc;
};

class mapTool :public scene
{
private:
	HWND m_hWndChildSample;
	HWND m_hWndChildSelect;

	image*	m_pTileSet;
	image*	m_pObject;
	image*	m_pbg;

	tagTile m_pTiles[TILE_X * TILE_Y];
	tagSampleTile m_pSampleTiles[SAMPLE_TILE_X * SAMPLE_TILE_Y];
		
	std::vector<int> m_vecSelectedTile;
	std::vector<int>::iterator m_iterSelectedTile;

	int	m_nImageX;

	bool m_isObject;

	int m_sampleTileIndex;

	int m_selectNum;
	int m_selectX;
	int m_selectY;
	int m_startX;
	int m_startY;

	bool m_isClick = false;
	bool m_isAddvec = false;
	bool m_isDrag = false;
	bool m_isDragSave = false;
	bool m_isClickSave = false;

	RECT m_rcSave;

public:
	mapTool();
	~mapTool();

	virtual HRESULT init();
	virtual void release();
	virtual void update();
	virtual void render(HDC hdc);
	LRESULT MainProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

	LRESULT ChildMapSampleProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

	void sampleTileSave();
	void TileSet();
	void TileObjSet();
	void objectEraser();
};

