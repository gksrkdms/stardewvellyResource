#include "stdafx.h"
#include "mainGame.h"
#include "mapTool.h"

HWND hButtonOpenFileDialog;
HWND hEditFileToBeOpened;
OPENFILENAME OFN;
const UINT nFileNameMaxLen = 512;
char szFileName[nFileNameMaxLen];
TCHAR szFileName2[256] = _T("");

void mainGame::setBackBuffer()
{
	m_pBackBuffer = new image;
	m_pBackBuffer->init(WINSIZEX, WINSIZEY);
}

HRESULT mainGame::init()
{
	hdc = GetDC(g_hWnd);

	KEYMANAGER->init();
	IMAGEMANAGER->init();
	TIMEMANAGER->init();
	SCENEMANAGER->init();

	setBackBuffer();

	// �ʿ��� ���ҽ� �̸� �ε�
	imgload();

	// Maptool
	m_pMap = new mapTool;
	SCENEMANAGER->addScene("maptool", m_pMap);

	// scene test
	//m_pTitleScene = new titleScene;
	//SCENEMANAGER->addScene("title", m_pTitleScene);

	//m_pBattleScene = new battleScene;
	//SCENEMANAGER->addScene("battle", m_pBattleScene);

	//m_pLoadingScene = new loadingScene_1;
	//SCENEMANAGER->addLoadingScene("loading_1", m_pLoadingScene);

	//m_pUiTestScene = new uiTestScene;
	//SCENEMANAGER->addScene("uiTest", m_pUiTestScene);

	//m_pPixelCollisionScene = new pixelCollision;
	//SCENEMANAGER->addScene("pixelCollision", m_pPixelCollisionScene);
	//
	//m_pTileMap = new tileMap;
	//SCENEMANAGER->addScene("tile", m_pTileMap);

	SCENEMANAGER->changeScene("maptool");
	

	return S_OK;
}

void mainGame::release()
{
	SAFE_DELETE(m_pBackBuffer);

	ReleaseDC(g_hWnd, hdc);

	DATAMANAGER->release();
	KEYMANAGER->release();
	IMAGEMANAGER->release();
	TIMEMANAGER->release();
	SCENEMANAGER->release();

	DATAMANAGER->releaseSingleton();
	KEYMANAGER->releaseSingleton();
	IMAGEMANAGER->releaseSingleton();
	TIMEMANAGER->releaseSingleton();
	SCENEMANAGER->releaseSingleton();

}

LRESULT mainGame::MainProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	if (SCENEMANAGER->getSceneName() == "maptool")
	{
		m_pMap->MainProc(hWnd, iMessage, wParam, lParam);
	}

	else
	{
		switch (iMessage)
		{
		case WM_CREATE:
			g_wndCount++;
			break;

		case WM_LBUTTONDOWN:

			break;

		case WM_MOUSEMOVE:
			g_ptMouse.x = LOWORD(lParam);
			g_ptMouse.y = HIWORD(lParam);

			//if (click)
			//{
			//	GetWindowRect(g_hWnd, &rc);
			//	rc.left += LOWORD(lParam) - g_ptMouse.x;
			//	rc.top += HIWORD(lParam) - g_ptMouse.y;
			//	g_ptMouse.x = LOWORD(lParam);
			//	g_ptMouse.y = HIWORD(lParam);
			//}				
			break;

		case WM_LBUTTONUP:
			break;

		case WM_KEYDOWN:
			switch (wParam)
			{
			case VK_LEFT:
				g_hMapTool = CreateWindow("MapTool", "MapTool", WS_POPUPWINDOW | WS_CAPTION, 0, 0, 500, 200, NULL, (HMENU)NULL, g_hInstance, NULL);
				ShowWindow(g_hMapTool, SW_SHOWNORMAL);
				break;

			case VK_ESCAPE:
				break;
			}
			return 0;

		case WM_INITDIALOG:
			break;

		case WM_PRINT:
			break;

			//case WM_COMMAND:
			//{
			//	switch (LOWORD(wParam))
			//	{
			//		//save
			//	case 0:
			//		OPENFILENAME ofn;

			//		ZeroMemory(&ofn, sizeof(OPENFILENAME));
			//		ofn.lStructSize = sizeof(OPENFILENAME);
			//		ofn.hwndOwner = hWnd;
			//		ofn.lpstrFilter = _T("Map Files(*.map)\0*.map\0All Files (*.*)\0*.*\0");
			//		ofn.lpstrFile = szFileName;
			//		ofn.nMaxFile = nFileNameMaxLen;
			//		ofn.lpstrDefExt = "map";
			//		//ofn.nFilterIndex = 1;
			//		//ofn.lpstrFileTitle = szFileName;
			//		//ofn.nMaxFileTitle = 0;
			//		//ofn.lpstrInitialDir = NULL;
			//		ofn.Flags = OFN_OVERWRITEPROMPT;
			//		GetSaveFileName(&ofn);

			//		//if (0 != GetOpenFileName(&OFN))
			//		//{
			//		//}
			//		
			//		m_pTileMap->saveMap(szFileName);
			//		//MessageBox(g_hWnd, TEXT("dd"), TEXT("ddkkk"), MB_OK);
			//		break;

			//		// load
			//	case 1:

			//		memset(&OFN, 0, sizeof(OPENFILENAME));
			//		OFN.lStructSize = sizeof(OPENFILENAME);
			//		OFN.hwndOwner = hWnd;
			//		OFN.lpstrFilter = "Map Files(*.map)\0*.map\0All Files (*.*)\0*.*\0";
			//		OFN.lpstrFile = szFileName;
			//		OFN.nMaxFile = nFileNameMaxLen;

			//		if (0 != GetOpenFileName(&OFN))
			//		{
			//			SetWindowText(hEditFileToBeOpened, OFN.lpstrFile);
			//			m_pTileMap->loadMap(OFN.lpstrFile);
			//		}
			//		return TRUE;

			//		break;

			//		// terrain
			//	case 2:
			//		m_pTileMap->setObject(false);
			//		break;

			//		// object
			//	case 3:
			//		m_pTileMap->setObject(true);
			//		break;

			//		// eraser
			//	case 4:
			//		m_pTileMap->objectEraser();
			//		break;
			//	}
			//	break;
			//}

		case WM_DESTROY:
			g_wndCount--;
			if (g_wndCount == 0)
			{
				PostQuitMessage(0);
			}
			return 0;
		}
	}	

	return DefWindowProc(hWnd, iMessage, wParam, lParam);
}

LRESULT mainGame::ChildMapSampleProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	return m_pMap->ChildMapSampleProc(hWnd, iMessage, wParam, lParam);
	//return DefWindowProc(hWnd, iMessage, wParam, lParam);
}


void mainGame::update()
{
	InvalidateRect(g_hWnd, NULL, false);

	SCENEMANAGER->update();
}

void mainGame::render()
{
	HDC backDC = m_pBackBuffer->getMemDC();

	SCENEMANAGER->render(backDC);

	m_pBackBuffer->render(hdc, 0, 0);
}

void mainGame::imgload()
{
	// Ÿ�ϸ�img
	// background
	IMAGEMANAGER->addImage("earth", "image/maptool/Ǯ����.bmp", 160, 160, 10,10,true, RGB(255, 0, 255));
	// object
	IMAGEMANAGER->addImage("earthObj", "image/maptool/Ǯ������obj.bmp", 48, 48,3,3, true, RGB(255, 0, 255));
	// background
	IMAGEMANAGER->addImage("whitebackground", "image/background.bmp", WINSIZEX, WINSIZEY);


}


mainGame::mainGame()
{
}


mainGame::~mainGame()
{
}
