#pragma once
#include "scene.h"

#define TILE_X	50
#define TILE_Y	50

#define SAMPLE_TILE_X	16
#define SAMPLE_TILE_Y	16

#define TILE_SIZE_1	16
#define TILE_SIZE_2	32


enum TERRAIN
{
	GRASS,
	WATER,
	EARTH,
	CEMENT,
	ROAD,
	TR_NUM
};

enum OBJECT
{
	BLOCK_1,
	BLOCK_2,
	FLAG_RED,
	FLAG_BLUE,
	BUSH_1,
	BUSH_2,
	BUSH_3,
	ROCK_BIG,
	ROCK_SMALL,
	BRANCH_1,
	HOUSE,
	MYHOME,
	SHOP,
	OB_NUM
};

struct tagTile
{
	TERRAIN terrain;
	OBJECT object;

	int terrainFrameX; // Ÿ���� ������ �ִ� ��������
	int terrainFrameY;

	int objectFrameX; // Ÿ���� ������ �ִ� ������Ʈ����
	int objectFrameY;

	RECT rc;
};

struct tagSampleTile
{
	int frameX;
	int frameY;

	RECT rc;
};

class mapTool :public scene
{
private:
	HWND m_hWndPopUp;

	image*	m_pTileSet;
	image*	m_pObject;

	//tagTile m_pTiles[TILE_X * TILE_Y];
	//tagSampleTile m_pSampleTiles[SAMPLE_TILE_X * SAMPLE_TILE_Y];
	RECT m_rcSelectedTile;

	bool m_isObject;

public:
	mapTool();
	~mapTool();

	virtual HRESULT init();
	virtual void release();
	virtual void update();
	virtual void render(HDC hdc);
};

