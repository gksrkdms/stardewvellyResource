#pragma once
class mapTool
{
private:
	HWND m_hWndPopUp;

public:
	mapTool();
	~mapTool();

	virtual HRESULT init();
	virtual void release();
	virtual void update();
	virtual void render(HDC hdc);
	LRESULT WndMapPopupProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);
};

