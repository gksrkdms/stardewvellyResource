#include "stdafx.h"
#include "mainGame.h"

HWND hButtonOpenFileDialog;
HWND hEditFileToBeOpened;
OPENFILENAME OFN;
const UINT nFileNameMaxLen = 512;
char szFileName[nFileNameMaxLen];
TCHAR szFileName2[256] = _T("");

void mainGame::setBackBuffer()
{
	m_pBackBuffer = new image;
	m_pBackBuffer->init(WINSIZEX, WINSIZEY);
}

HRESULT mainGame::init()
{
	hdc = GetDC(g_hWnd);

	KEYMANAGER->init();
	IMAGEMANAGER->init();
	TIMEMANAGER->init();
	SCENEMANAGER->init();

	setBackBuffer();

	// �ʿ��� ���ҽ� �̸� �ε�

	// scene test
	//m_pTitleScene = new titleScene;
	//SCENEMANAGER->addScene("title", m_pTitleScene);

	//m_pBattleScene = new battleScene;
	//SCENEMANAGER->addScene("battle", m_pBattleScene);

	//m_pLoadingScene = new loadingScene_1;
	//SCENEMANAGER->addLoadingScene("loading_1", m_pLoadingScene);

	//m_pUiTestScene = new uiTestScene;
	//SCENEMANAGER->addScene("uiTest", m_pUiTestScene);

	//m_pPixelCollisionScene = new pixelCollision;
	//SCENEMANAGER->addScene("pixelCollision", m_pPixelCollisionScene);
	//
	//m_pTileMap = new tileMap;
	//SCENEMANAGER->addScene("tile", m_pTileMap);

	//SCENEMANAGER->changeScene("tile");
	

	return S_OK;
}

void mainGame::release()
{
	SAFE_DELETE(m_pBackBuffer);

	ReleaseDC(g_hWnd, hdc);

	DATAMANAGER->release();
	KEYMANAGER->release();
	IMAGEMANAGER->release();
	TIMEMANAGER->release();
	SCENEMANAGER->release();

	DATAMANAGER->releaseSingleton();
	KEYMANAGER->releaseSingleton();
	IMAGEMANAGER->releaseSingleton();
	TIMEMANAGER->releaseSingleton();
	SCENEMANAGER->releaseSingleton();

}

LRESULT mainGame::MainProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{

	switch (iMessage)
	{
	case WM_MOUSEMOVE:
		g_ptMouse.x = LOWORD(lParam);
		g_ptMouse.y = HIWORD(lParam);
		break;
	case WM_KEYDOWN:
		switch (wParam)
		{
		case VK_LEFT:
			ShowWindow(g_hMapTool, SW_SHOWNORMAL);
			break;

		case VK_ESCAPE:
			PostQuitMessage(0);
			return 0;			
		}
		break;
		
	case WM_CREATE:
		//g_hMapTool = hWnd;
		//g_hMapTool = CreateWindow("Map Tool", NULL, WS_POPUP | WS_BORDER, 0, 0, 0, 0, hWnd, (HMENU)0, g_hInstance, NULL);
		break;

	case WM_INITDIALOG:
		break;

	//case WM_COMMAND:
	//{
	//	switch (LOWORD(wParam))
	//	{
	//		//save
	//	case 0:
	//		OPENFILENAME ofn;

	//		ZeroMemory(&ofn, sizeof(OPENFILENAME));
	//		ofn.lStructSize = sizeof(OPENFILENAME);
	//		ofn.hwndOwner = hWnd;
	//		ofn.lpstrFilter = _T("Map Files(*.map)\0*.map\0All Files (*.*)\0*.*\0");
	//		ofn.lpstrFile = szFileName;
	//		ofn.nMaxFile = nFileNameMaxLen;
	//		ofn.lpstrDefExt = "map";
	//		//ofn.nFilterIndex = 1;
	//		//ofn.lpstrFileTitle = szFileName;
	//		//ofn.nMaxFileTitle = 0;
	//		//ofn.lpstrInitialDir = NULL;
	//		ofn.Flags = OFN_OVERWRITEPROMPT;
	//		GetSaveFileName(&ofn);

	//		//if (0 != GetOpenFileName(&OFN))
	//		//{
	//		//}
	//		
	//		m_pTileMap->saveMap(szFileName);
	//		//MessageBox(g_hWnd, TEXT("dd"), TEXT("ddkkk"), MB_OK);
	//		break;

	//		// load
	//	case 1:

	//		memset(&OFN, 0, sizeof(OPENFILENAME));
	//		OFN.lStructSize = sizeof(OPENFILENAME);
	//		OFN.hwndOwner = hWnd;
	//		OFN.lpstrFilter = "Map Files(*.map)\0*.map\0All Files (*.*)\0*.*\0";
	//		OFN.lpstrFile = szFileName;
	//		OFN.nMaxFile = nFileNameMaxLen;

	//		if (0 != GetOpenFileName(&OFN))
	//		{
	//			SetWindowText(hEditFileToBeOpened, OFN.lpstrFile);
	//			m_pTileMap->loadMap(OFN.lpstrFile);
	//		}
	//		return TRUE;

	//		break;

	//		// terrain
	//	case 2:
	//		m_pTileMap->setObject(false);
	//		break;

	//		// object
	//	case 3:
	//		m_pTileMap->setObject(true);
	//		break;

	//		// eraser
	//	case 4:
	//		m_pTileMap->objectEraser();
	//		break;
	//	}
	//	break;
	//}
	
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}

	return DefWindowProc(hWnd, iMessage, wParam, lParam);
}

void mainGame::update()
{
	InvalidateRect(g_hWnd, NULL, false);

	SCENEMANAGER->update();
}

void mainGame::render()
{
	HDC backDC = m_pBackBuffer->getMemDC();

	SCENEMANAGER->render(backDC);

	m_pBackBuffer->render(hdc, 0, 0);
}

mainGame::mainGame()
{
}


mainGame::~mainGame()
{
}
