#include "stdafx.h"
#include "mapTool.h"

LPTSTR	g_lpszClass2 = (LPTSTR)TEXT("MapTool");


mapTool::mapTool()
{
}

mapTool::~mapTool()
{
}

HRESULT mapTool::init()
{

	m_hWndPopUp = CreateWindow(g_lpszClass2, g_lpszClass2, WS_OVERLAPPEDWINDOW, WINSTARTX,
		WINSTARTY,
		WINSIZEX,
		WINSIZEY, g_hWnd, (HMENU)NULL, g_hInstance, NULL);




	return S_OK;
}

void mapTool::release()
{
}

void mapTool::update()
{
}

void mapTool::render(HDC hdc)
{
}
