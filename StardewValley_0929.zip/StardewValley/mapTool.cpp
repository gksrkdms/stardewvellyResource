#include "stdafx.h"
#include "mapTool.h"

LPTSTR	g_lpszClass2 = (LPTSTR)TEXT("MapTool");


mapTool::mapTool()
{
}

mapTool::~mapTool()
{
}

HRESULT mapTool::init()
{

	m_hWndPopUp = CreateWindow(g_lpszClass2, g_lpszClass2, WS_OVERLAPPEDWINDOW, WINSTARTX,
		WINSTARTY,
		WINSIZEX,
		WINSIZEY, g_hWnd, (HMENU)NULL, g_hInstance, NULL);

	return S_OK;
}

void mapTool::release()
{
}

void mapTool::update()
{
}

void mapTool::render(HDC hdc)
{
}

LRESULT mapTool::WndMapPopupProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;

	switch (iMessage)
	{
	case WM_MOUSEMOVE:
		g_ptMouse.x = LOWORD(lParam);
		g_ptMouse.y = HIWORD(lParam);
		break;
	case WM_KEYDOWN:
		switch (wParam)
		{
		case VK_LEFT:
			//ShowWindow(m_hWndPopUp, SW_SHOWNORMAL);
			break;

		case VK_ESCAPE:
			PostQuitMessage(0);
			return 0;
		}
		break;

	case WM_PAINT:
		//TextOut(hdc, 0, 0, "ddd", 5);
		break;

	case WM_INITDIALOG:
		break;

		//case WM_COMMAND:
		//{
		//	switch (LOWORD(wParam))
		//	{
		//		//save
		//	case 0:
		//		OPENFILENAME ofn;

		//		ZeroMemory(&ofn, sizeof(OPENFILENAME));
		//		ofn.lStructSize = sizeof(OPENFILENAME);
		//		ofn.hwndOwner = hWnd;
		//		ofn.lpstrFilter = _T("Map Files(*.map)\0*.map\0All Files (*.*)\0*.*\0");
		//		ofn.lpstrFile = szFileName;
		//		ofn.nMaxFile = nFileNameMaxLen;
		//		ofn.lpstrDefExt = "map";
		//		//ofn.nFilterIndex = 1;
		//		//ofn.lpstrFileTitle = szFileName;
		//		//ofn.nMaxFileTitle = 0;
		//		//ofn.lpstrInitialDir = NULL;
		//		ofn.Flags = OFN_OVERWRITEPROMPT;
		//		GetSaveFileName(&ofn);

		//		//if (0 != GetOpenFileName(&OFN))
		//		//{
		//		//}
		//		
		//		m_pTileMap->saveMap(szFileName);
		//		//MessageBox(g_hWnd, TEXT("dd"), TEXT("ddkkk"), MB_OK);
		//		break;

		//		// load
		//	case 1:

		//		memset(&OFN, 0, sizeof(OPENFILENAME));
		//		OFN.lStructSize = sizeof(OPENFILENAME);
		//		OFN.hwndOwner = hWnd;
		//		OFN.lpstrFilter = "Map Files(*.map)\0*.map\0All Files (*.*)\0*.*\0";
		//		OFN.lpstrFile = szFileName;
		//		OFN.nMaxFile = nFileNameMaxLen;

		//		if (0 != GetOpenFileName(&OFN))
		//		{
		//			SetWindowText(hEditFileToBeOpened, OFN.lpstrFile);
		//			m_pTileMap->loadMap(OFN.lpstrFile);
		//		}
		//		return TRUE;

		//		break;

		//		// terrain
		//	case 2:
		//		m_pTileMap->setObject(false);
		//		break;

		//		// object
		//	case 3:
		//		m_pTileMap->setObject(true);
		//		break;

		//		// eraser
		//	case 4:
		//		m_pTileMap->objectEraser();
		//		break;
		//	}
		//	break;
		//}

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}

	return DefWindowProc(hWnd, iMessage, wParam, lParam);
}
